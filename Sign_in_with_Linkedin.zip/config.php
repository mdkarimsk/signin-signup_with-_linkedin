<?php
define('DB_HOST', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'test');
define('DB_USER_TBL', 'users');

define('LIN_CLIENT_ID', '77dik2gq024cfq');
define('LIN_CLIENT_SECRET', 'fAq1YN1HeEk4TxCH');
define('LIN_REDIRECT_URL', 'http://localhost/linkedin_api_itegration/sign-in-with-linkedin/index.php');
define('LIN_SCOPE', 'r_liteprofile r_emailaddress');
if(!session_id()){
    session_start();
}
require_once 'linkedin-oauth-client-php/http.php';
require_once 'linkedin-oauth-client-php/oauth_client.php';

?>

